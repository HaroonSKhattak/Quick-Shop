const router = require('express').Router();
const User = require("../models/user");
const { validateInputs } = require("../middlewares/validator")

router.post('/register', validateInputs(['username', 'email', 'password']), async (req, res) => {
    try {
        let { email } = req.body
        const oldData = await User.findOne({ email })
        if (oldData != null) {
            return res.json({
                status: 'error',
                message: 'this email already exists'
            })
        }
        const data = await User.create({ ...req["validData"] })
        return res.json({
            status: 'success',
            data
        })
    } catch (error) {
        return res.json(error)
    }
})

router.post('/login', validateInputs(['email', 'password']), async (req, res) => {
    try {
        let { email, password } = req.body
        const oldData = await User.findOne({ email })
        if (oldData == null) {
            return res.json({
                status: 'error',
                message: 'this email does not exist'
            })
        }
        const data = await User.findOne({ email, password })
        if (data == null) {
            return res.json({
                status: 'error',
                message: 'wrong password'
            })
        }
        return res.json({
            status: 'success',
            data
        })
    } catch (error) {
        return res.json(error)
    }
})


router.put('/:id', validateInputs(['title', 'code']), async (req, res) => {
    try {
        let { title, code } = req.body
        let { id } = req.params
        const oldData = await User.findOne({ $or: [{ title }, { code }] })
        if (oldData != null) {
            return res.json({
                message: "already in use"
            })
        }
        const data = await User.findByIdAndUpdate(id, { title })
        return res.json({
            data
        })
    } catch (error) {
        return res.json(error)
    }
})


router.delete('/delete/:id', async (req, res) => {
    try {
        let { id } = req.params
        if (!await User.findByIdAndDelete(id)) {
            return res.status(400).json("Color does not exist")
        }
        return res.json("record deleted successfully")
    } catch (error) {
        return res.json(error)
    }
})


router.get('/getall', async (req, res) => {
    try {
        return res.json({ data: await User.find() })
    } catch (error) {
        return res.json(error)
    }
})


router.get('/:id', async (req, res) => {
    try {
        let { id } = req.params
        return res.json({ data: await User.findById(id) })
    } catch (error) {
        return res.json(error)
    }
})





module.exports = router
