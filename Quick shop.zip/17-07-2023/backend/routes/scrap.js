const router = require("express").Router();
const rp = require("request-promise");
const cheerio = require("cheerio");

router.post("/", async (req, res) => {
  try {
    const { query } = req.body;
    const searchUrl = `https://priceoye.pk/search?q=${query}`;
    rp(searchUrl)
      .then(function (html) {
        //success!
        const productList = [];
        const $ = cheerio.load(html);
        const products = $(".productBox");
        products.each(function () {
          let title = $(this)
            .find(".p-title")
            .text()
            .replace(/\\n/g, "")
            .trim();

          let price = $(this).find(".price-box").text().trim();
          const imgUrl = $(this).find(".image-box>amp-img").attr("src");

          productList.push({
            title,
            price,
            url: imgUrl,
          });
        });
        res.json({ data: productList });
      })
      .catch(function (err) {
        res.json({ data: [] });
        //handle error
      });
  } catch (error) {
    return res.json(error);
  }
});

module.exports = router;
