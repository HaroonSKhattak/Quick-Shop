const router = require('express').Router();
const Category = require("../models/category")
const { validateInputs } = require("../middlewares/validator")

router.post('/create', validateInputs(['title']), async (req, res) => {
    try {
        let { title } = req.body
        const oldData = await Category.findOne({ title })
        if (oldData != null) {
            return res.json({
                status: 'error',
                message: 'this title already exists'
            })
        }
        const data = await Category.create({ ...req["validData"] })
        return res.json({
            status: 'success',
            data
        })
    } catch (error) {
        return res.json(error)
    }
})


router.put('/:id', validateInputs(['title']), async (req, res) => {
    try {
        let { title } = req.body
        let { id } = req.params
        const oldData = await Category.findOne({ title })
        if (oldData != null) {
            return res.json({
                message: "this title already in use"
            })
        }
        const data = await Category.findByIdAndUpdate(id, { title })
        return res.json({
            data
        })
    } catch (error) {
        return res.json(error)
    }
})


router.delete('/:id', async (req, res) => {
    try {
        let { id } = req.params
        if (!await Category.findByIdAndDelete(id)) {
            return res.status(400).json("Category does not exist")
        }
        return res.json("record deleted successfully")
    } catch (error) {
        return res.json(error)
    }
})


router.get('/getall', async (req, res) => {
    try {
        return res.json({ data: await Category.find() })
    } catch (error) {
        return res.json(error)
    }
})


router.get('/:id', validateInputs(['title']), async (req, res) => {
    try {
        let { id } = req.params
        return res.json({ data: await Category.findById(id) })
    } catch (error) {
        return res.json(error)
    }
})





module.exports = router