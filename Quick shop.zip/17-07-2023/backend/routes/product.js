const router = require('express').Router();
const Product = require("../models/product")
const { validateInputs } = require("../middlewares/validator")


// CREATE A PRODUCT


router.post('/create', validateInputs(['title', 'description', 'color', 'price', 'available', 'company']), async (req, res) => {
    try {
        let { title } = req.body
        const oldData = await Product.findOne({ title })
        if (oldData != null) {
            return res.json({
                status: 'error',
                message: 'this title already exists'
            })
        }
        const data = await Product.create({ ...req["validData"] })
        return res.json({
            status: 'success',
            data
        })
    } catch (error) {
        return res.json(error)
    }
})


// UPDATE A PRODUCT


router.put('/:id', async (req, res) => {
    try {
      let { title, price } = req.body;
      let { id } = req.params;
      const oldData = await Product.findOne({ title, price });
  
      if (oldData !== null && oldData._id.toString() !== id) {
        return res.json({
          message: "This title already in use"
        });
      }
  
      const data = await Product.findByIdAndUpdate(id, req.body, { new: true });
  
      if (!data) {
        return res.json({
          message: "Product not found"
        });
      }
  
      return res.json({
        data: data
      });
    } catch (error) {
      return res.json(error);
    }
  });


// DELETE A PRODUCT


router.delete('/:id', async (req, res) => {
    try {
        let { id } = req.params
        if (!await Product.findByIdAndDelete(id)) {
            return res.status(400).json("Product does not exist")
        }
        return res.json("record deleted successfully")
    } catch (error) {
        return res.json(error)
    }
})


// GETALL PRODUCTS


router.get('/getAll', async (req, res) => {
    try {
        return res.json({ data: await Product.find() })
    } catch (error) {
        return res.json(error)
    }
})


// GET A PRODUCT

router.get('/:id', async (req, res) => {
    try {
        let { id } = req.params
        return res.json({ data: await Product.findById(id) })
    } catch (error) {
        return res.json(error)
    }
})





module.exports = router