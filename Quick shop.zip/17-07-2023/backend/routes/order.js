const express = require('express');
const Order = require('../models/order');
const Cart = require('../models/cart');
const Product = require('../models/product');
const router = express.Router();

router.post('/placeOrder', async (req, res) => {
    try {
        const { userId, shippingAddress } = req.body;

        // Retrieve the user's cart
        const cart = await Cart.findOne({ userId });

        if (!cart) {
            return res.status(404).json({ message: 'Cart not found' });
        }

        // Create the order
        const order = new Order({
            userId: cart.userId,
            products: cart.products,
            totalPrice: calculateTotalPrice(cart.products),
            shippingAddress,
            status: 'pending',
        });

        // Save the order to the database
        await order.save();

        // Clear the user's cart
        await Cart.findOneAndDelete({ userId });

        res.status(200).json({ message: 'Order placed successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'An error occurred while placing the order' });
    }
});


const calculateTotalPrice = (products) => {
    let totalPrice = 0;
    products.forEach((product) => {
        totalPrice += product.quantity * getProductPrice(product.productId); // Implement getProductPrice based on your specific logic
    });
    return totalPrice;
};


const getProductPrice = async (productId) => {
    // Implement logic to retrieve the price of a product based on the productId
    const product = await Product.findById(productId);
    return product.price
};


router.get("/getAll", async (req, res) => {
    try {
        return res.json({
            status: "success",
            data: await Order.find()
        })
    } catch (error) {
        return res.json({
            status: "error",
            message: error.message
        })
    }
})




module.exports = router;
