const router = require('express').Router();
const Color = require("../models/color")
const { validateInputs } = require("../middlewares/validator")

router.post('/create', validateInputs(['title', 'code']), async (req, res) => {
    try {
        let {title} = req.body
        const oldData = await Color.findOne({$or:[{title}, {code}]})
        if (oldData != null) {
            return res.json({
                status: 'error',
                message: 'this title already exists'
            })
        }
        const data = await Color.create({ ...req["validData"] })
        return res.json({
            status: 'success',
            data
        })
    } catch (error) {
        return res.json(error)
    }
})


router.put('/:id', validateInputs(['title', 'code']), async (req, res) => {
    try {
        let { title, code } = req.body
        let { id } = req.params
        const oldData = await Color.findOne({$or:[{title}, {code}]})
        if (oldData != null){
            return res.json({
                message: "already in use"
            })
        }
        const data = await Color.findByIdAndUpdate(id, { title })
        return res.json({
            data
        })
    } catch (error) {
        return res.json(error)
    }
})


router.delete('/:id', async (req, res) => {
    try {
        let { id } = req.params
        if (!await Color.findByIdAndDelete(id)) {
            return res.status(400).json("Color does not exist")
        }
        return res.json("record deleted successfully")
    } catch (error) {
        return res.json(error)
    }
})


router.get('/getall', async (req, res) => {
    try {
        return res.json({ data: await Color.find() })
    } catch (error) {
        return res.json(error)
    }
})


router.get('/:id', async (req, res) => {
    try {
        let { id } = req.params
        return res.json({ data: await Color.findById(id) })
    } catch (error) {
        return res.json(error)
    }
})





module.exports = router