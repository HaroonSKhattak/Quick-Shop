const router = require('express').Router();

const Cart = require("../models/cart")


// router.post('/add', async (req, res) => {
//     try {
//         const { userId, products } = req.body;
//         const old = await Cart.findOne({ userId });
//         if (old == null) {
//             const cart = Cart.create({ userId, products });
//             return res.json({ status: "success", data: cart });
//         }
//         await Cart.findOneAndUpdate({ userId }, { products });
//         return res.json({ status: "success", data: await Cart.findOne({ userId }) });
//     } catch (error) {
//         res.status(500).json({ error: 'Failed to create cart' });
//     }
// });

router.post('/add', async (req, res) => {
    try {
        const { userId, productId, quantity } = req.body;

        // Find the user's cart or create a new one if it doesn't exist
        let cart = await Cart.findOne({ userId });

        if (!cart) {
            cart = new Cart({
                userId,
                products: [],
            });
        }

        // Check if the product already exists in the cart
        const existingProductIndex = cart.products.findIndex(
            (product) => product.productId === productId
        );

        if (existingProductIndex !== -1) {
            // Product already exists, update the quantity
            cart.products[existingProductIndex].quantity += quantity;
        } else {
            // Product doesn't exist, add it to the cart
            cart.products.push({ productId, quantity });
        }

        // Save the cart to the database
        await cart.save();

        res.status(200).json({ message: 'Product added to cart successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'An error occurred while adding the product to cart' });
    }
});


router.get('/getByUser/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const cart = await Cart.findOne({ userId });
        if (cart) {
            res.json(cart);
        } else {
            res.status(404).json({ error: 'Cart not found' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch cart' });
    }
});


// router.put('/carts/:userId', async (req, res) => {
//     try {
//         const { userId } = req.params;
//         const { products } = req.body;
//         const updatedCart = await Cart.findOneAndUpdate({ userId }, { products }, { new: true });
//         if (updatedCart) {
//             res.json(updatedCart);
//         } else {
//             res.status(404).json({ error: 'Cart not found' });
//         }
//     } catch (error) {
//         res.status(500).json({ error: 'Failed to update cart' });
//     }
// });

router.delete('/deleteByUser/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const deletedCart = await Cart.findOneAndDelete({ userId });
        if (deletedCart) {
            return res.json({ message: 'Cart deleted successfully' });
        } else {
            return res.status(404).json({ error: 'Cart not found' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete cart' });
    }
});





module.exports = router
