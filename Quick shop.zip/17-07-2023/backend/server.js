const dotenv = require("dotenv").config();
const cors = require("cors");

const express = require("express");
const app = express();
const mongoose = require("mongoose");

const connect = async () => {
  try {
    await mongoose.connect(process.env.dbURL);
    console.log("db connected");
  } catch (error) {
    console.log(error);
    console.log("db not connected");
  }
};
connect();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const Router = require("./router");
Router(app);

app.listen(process.env.PORT, () => {
  console.log("server started");
});
