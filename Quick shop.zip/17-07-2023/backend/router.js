const category = require("./routes/category");
const color = require("./routes/color");
const company = require("./routes/company");
const product = require("./routes/product");
const cart = require("./routes/cart");
const user = require("./routes/user");
const order = require("./routes/order");
const scrap = require("./routes/scrap");
module.exports = (app) => {
  app.use("/category", category);
  app.use("/color", color);
  app.use("/company", company);
  app.use("/product", product);
  app.use("/cart", cart);
  app.use("/user", user);
  app.use("/order", order);
  app.use("/scrap", scrap);
};
