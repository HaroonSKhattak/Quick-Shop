const mongoose = require('mongoose');
const colorSchema = new mongoose.Schema(
    {
        title: {
            type: String,
            required: true,
            unique: true
        },
        code: {
            type: String,
            required: true,
            unique: true
        }
    },
    { timestamps: true }

);


module.exports = mongoose.model("color", colorSchema);