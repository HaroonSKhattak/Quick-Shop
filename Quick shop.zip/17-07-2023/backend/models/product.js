const mongoose = require('mongoose');
const productSchema = new mongoose.Schema(
    {
        title: {
            type: String,
            required: true,
            unique: true
        },
        description: {
            type: String,
            required: true
        },
        color: {
            type: Array
        },
        price: {
            type: Number,
            required: true
        },
        available: {
            type: Boolean,
            required: true
        },
        company: {
            type: String,
            required: true
        }
    },
    { timestamps: true }
);


module.exports = mongoose.model("product", productSchema);