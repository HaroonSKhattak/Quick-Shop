import React, { useEffect, useState } from "react";
import { useFilterContext } from "../context/filter_context";
import GridView from "./GridView";
import ListView from "./ListView";
import axios from "axios";
import SingleProduct from "../SingleProduct";

const ProductList = () => {
  const [productListData, setProductList] = useState([]);
  console.log("productListData", productListData)

  useEffect(() => {
    axios.get(`${process.env.REACT_APP_API_URL}/product/getAll`)
      .then((response) => {
        setProductList(response?.data?.data)
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  }, []);

  const { filter_products, grid_view } = useFilterContext();

  if (grid_view === true) {
    return <GridView products={productListData} />;
  }

  if (grid_view === false) {
    return <ListView products={productListData} />;
  }

};

export default ProductList;
