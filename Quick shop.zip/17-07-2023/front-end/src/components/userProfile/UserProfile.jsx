import React, { useState } from 'react';
import './style.css';
import Dashboard from './dashboard/Dashboard';
import UserProfileProducts from './products/UserProfileProducts';
import UserProfileCompany from './company/UserProfileCompany';
import UserProfileCategory from './category/UserProfileCategory';
import { useNavigate } from 'react-router-dom';
import AdminProfileOrder from './order/AdminProfileOrder';
import AdminUser from './user/AdminUser';

const UserProfile = () => {
  const route = useNavigate();
  const isAdmin = JSON.parse(localStorage.getItem("user"));

  const navigationItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: 'fas fa-home',
      component: <Dashboard />
    },
    {
      id: 'products',
      label: 'Products',
      icon: 'fas fa-user',
      component: <UserProfileProducts />
    },
    {
      id: 'company',
      label: 'Company',
      icon: 'fas fa-user',
      component: <UserProfileCompany />
    },
    {
      id: 'category',
      label: 'Category',
      icon: 'fas fa-user',
      component: <UserProfileCategory />
    },
    {
      id: 'logout',
      label: 'Logout',
      icon: 'fas fa-user',
    },
    // Add more navigation items here
  ];

  const [activeId, setActiveId] = useState(navigationItems[0].id);
  console.log("activeId", activeId)

  const handleNavigationItemClick = (id, event) => {
    event.preventDefault();
    setActiveId(id);
    if (id === 'logout') {
      localStorage.clear();
      route('/'); // Corrected: use `navigate` to navigate to '/'
    }
  };

  const updatedArr = isAdmin.data.email === 'admin@gmail.com'
  ? [
      ...navigationItems.slice(0, 4), // Copy the first 4 items
      {
        id: 'order',
        label: 'Order',
        icon: 'fas fa-user',
        component: <AdminProfileOrder />
      },
      {
        id: 'user',
        label: 'User',
        icon: 'fas fa-user',
        component: <AdminUser />
      },
      ...navigationItems.slice(4) // Copy the remaining items (from index 4 onwards)
    ]
  : navigationItems;


  const activeComponent = updatedArr.find((item) => item.id === activeId).component;

  return (
    <div className="container">
      <div className="row">
        <div className="col-lg-4">
          <div className="ltn__tab-menu-list mb-50">
            <div className="nav">
              {updatedArr.map((item) => (
                <span
                  key={item.id}
                  className={activeId === item.id ? 'active show' : ''}
                  onClick={(e) => handleNavigationItemClick(item.id, e)}
                >
                  {item.label} <i className={item.icon}></i>
                </span>
              ))}
            </div>
          </div>
        </div>
        <div className="col-lg-8">
          {activeComponent}
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
