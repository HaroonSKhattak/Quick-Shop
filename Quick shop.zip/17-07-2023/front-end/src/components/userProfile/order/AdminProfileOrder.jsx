import React, { useEffect, useState } from 'react';
import '../style.css';
import axios from 'axios';

const AdminProfileOrder = () => {
  const [getAllProduct, setGetAllProduct] = useState([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  useEffect(() => {
    axios.get(`${process.env.REACT_APP_API_URL}/order/getAll`)
      .then((response) => {
        setGetAllProduct(response?.data?.data)
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  }, [])

  return (
    <>
      <div className='user-table-wrapper'>
        <div className='user-table-btn'>
          <button typeof='button' onClick={() => setIsAddModalOpen(true)}>Create Company</button>
        </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Delete Company</th>
              </tr>
            </thead>
            <tbody>
              {getAllProduct.map((row, index) => (
                <tr key={index}>
                  <td>{row?.title}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  )
}

export default AdminProfileOrder