import React, { useEffect, useState } from 'react';
import '../style.css';
import axios from 'axios';
import UserProfileModal from './UserProfileModal/UserProfileModal';
import UserProfileModalUpdate from './userProfileModalUpdate/UserProfileModalUpdate';

const UserProfileProducts = () => {
  const [getAllProduct, setGetAllProduct] = useState([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [isAdminProduct, setIsAdminProduct] = useState({})
  const isAdmin = JSON.parse(localStorage.getItem("user"));

  const deleteData = async (id) => {
    try {
      const response = await axios.delete(`${process.env.REACT_APP_API_URL}/product/${id}`);
      console.log(response.data); // handle the response data
    } catch (error) {
      console.error(error); // handle error
    }
  };


  useEffect(() => {
    axios.get(`${process.env.REACT_APP_API_URL}/product/getAll`)
      .then((response) => {
        setGetAllProduct(response?.data?.data)
      })
      .catch((error) => {
        console.error('Error:', error);
      });
    deleteData()
  }, [])

  return (
    <>
      <div className='user-table-wrapper'>
        <div className='user-table-btn'>
          <button typeof='button' onClick={() => setIsAddModalOpen(true)}>Create Product</button>
        </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Price</th>
                <th>Available</th>
                <th>Company</th>
                <th>Delete Product</th>
                {isAdmin.data.email === 'admin@gmail.com' &&
                  <th>Update</th>
                }
              </tr>
            </thead>
            <tbody>
              {getAllProduct.map((row, index) => (
                <tr key={index}>
                  <td>{row?.title}</td>
                  <td>{row?.description}</td>
                  <td>{row?.price}</td>
                  <td>{row?.available ? "In Stock" : "Not Available"}</td>
                  <td>{row?.company}</td>
                  <td onClick={() => deleteData(row?._id)}>Delete</td>
                  {isAdmin.data.email === 'admin@gmail.com' &&
                    <td onClick={() => {setIsUpdateModalOpen(true); setIsAdminProduct(row)}}>Update</td>
                  }
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <UserProfileModal isAddModalOpen={isAddModalOpen} setIsAddModalOpen={setIsAddModalOpen} />
      <UserProfileModalUpdate isAddModalOpen={isUpdateModalOpen} setIsAddModalOpen={setIsUpdateModalOpen} isAdminProduct={isAdminProduct} />
    </>
  )
}

export default UserProfileProducts