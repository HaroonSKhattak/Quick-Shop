import React, { useEffect, useState } from 'react';
import { TextField, Button, Dialog, DialogContent, DialogTitle, FormControl, FormControlLabel, FormLabel, Grid, Radio, RadioGroup, } from '@mui/material';
import axios from 'axios';

const UserProfileModalUpdate = (props) => {
  const { isAddModalOpen, setIsAddModalOpen, isAdminProduct } = props;
  console.log("isAdminProduct", isAdminProduct)

  const [formValues, setFormValues] = useState({
    title: isAdminProduct?.title,
    price: isAdminProduct?.price,
  });

  const [errors, setErrors] = useState({
    title: '',
    price: '',
  });

  const handleInputChange = (event) => {
    const { name, value, type, checked } = event.target;
    const newValue = type === 'checkbox' ? checked : value;

    setFormValues((prevValues) => ({
      ...prevValues,
      [name]: newValue,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formErrors = validateForm();
    if (Object.keys(formErrors).length === 0) {
     try {
        await axios.put(`${process.env.REACT_APP_API_URL}/product/${isAdminProduct?._id}`, formValues)
     } catch(error) {
        console.log(error)
     }
     setIsAddModalOpen(false)
      // Reset form values
      setFormValues({
        title: '',
        price: '',
      });
      // Reset errors
      setErrors({
        title: '',
        price: '',
      });
    } else {
      // Update the errors state with the validation errors
      setErrors(formErrors);
    }
  };

  const validateForm = () => {
    const errors = {};

    // Title validation
    if (!formValues.title.trim()) {
      errors.title = 'Title is required';
    }

    // Price validation
    if (!formValues.price.trim()) {
      errors.price = 'Price is required';
    } else if (isNaN(formValues.price)) {
      errors.price = 'Price must be a number';
    }

    return errors;
  }

  useEffect(() => {handleSubmit()},[])

  return (
    <Dialog open={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} maxWidth="sm">
      <DialogTitle sx={{ fontSize: "16px", fontWeight: 600, color: "#333" }}>Update Product</DialogTitle>
      <DialogContent sx={{ mt: "15px" }}>
        <form className="form" onSubmit={handleSubmit}>
          <FormControl fullWidth className="form-control">
            <label className="products-title" htmlFor="title-input">Title</label>
            <TextField
              id="title-input"
              name="title"
              value={formValues.title}
              onChange={handleInputChange}
              required
              fullWidth
              className="input-field"
              error={!!errors.title}
              helperText={errors.title}
              InputProps={{ sx: { height: 40 } }}
            />
          </FormControl>
          <FormControl fullWidth className="form-control">
            <label className="products-title" htmlFor="price-input">Price</label>
            <TextField
              id="price-input"
              name="price"
              value={formValues.price}
              onChange={handleInputChange}
              type="number"
              required
              fullWidth
              className="input-field"
              error={!!errors.price}
              helperText={errors.price}
              InputProps={{ sx: { height: 40 } }}
            />
          </FormControl>
          <button type="submit"  className="submit-button">
            Submit
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default UserProfileModalUpdate;
