import React, { useEffect, useState } from 'react';
import { TextField, Button, Dialog, DialogContent, DialogTitle, FormControl, FormControlLabel, FormLabel, Grid, Radio, RadioGroup, } from '@mui/material';
import axios from 'axios';

const UserProfileModal = (props) => {
  const { isAddModalOpen, setIsAddModalOpen } = props;

  const [formValues, setFormValues] = useState({
    title: '',
    description: '',
    color: '',
    price: '',
    available: '',
    company: '',
  });

  const [errors, setErrors] = useState({
    title: '',
    description: '',
    color: '',
    price: '',
    available: '',
    company: '',
  });

  const handleInputChange = (event) => {
    const { name, value, type, checked } = event.target;
    const newValue = type === 'checkbox' ? checked : value;

    setFormValues((prevValues) => ({
      ...prevValues,
      [name]: newValue,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formErrors = validateForm();
    if (Object.keys(formErrors).length === 0) {
     try {
        await axios.post(`${process.env.REACT_APP_API_URL}/product/create`, formValues)
     } catch(error) {
        console.log(error)
     }
     setIsAddModalOpen(false)
      // Reset form values
      setFormValues({
        title: '',
        description: '',
        color: '',
        price: '',
        available: '',
        company: '',
      });
      // Reset errors
      setErrors({
        title: '',
        description: '',
        color: '',
        price: '',
        available: '',
        company: '',
      });
    } else {
      // Update the errors state with the validation errors
      setErrors(formErrors);
    }
  };

  const validateForm = () => {
    const errors = {};

    // Title validation
    if (!formValues.title.trim()) {
      errors.title = 'Title is required';
    }

    // Description validation
    if (!formValues.description.trim()) {
      errors.description = 'Description is required';
    }

    // Color validation
    if (!formValues.color.trim()) {
      errors.color = 'Color is required';
    }

    // Price validation
    if (!formValues.price.trim()) {
      errors.price = 'Price is required';
    } else if (isNaN(formValues.price)) {
      errors.price = 'Price must be a number';
    }

    // Available validation
    if (!formValues.available) {
      errors.available = 'Please select availability';
    }

    // Company validation
    if (!formValues.company.trim()) {
      errors.company = 'Company is required';
    }

    return errors;
  }

  useEffect(() => {handleSubmit()},[])

  return (
    <Dialog open={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} maxWidth="sm">
      <DialogTitle sx={{ fontSize: "16px", fontWeight: 600, color: "#333" }}>Add Product</DialogTitle>
      <DialogContent sx={{ mt: "15px" }}>
        <form className="form" onSubmit={handleSubmit}>
          <FormControl fullWidth className="form-control">
            <label className="products-title" htmlFor="title-input">Title</label>
            <TextField
              id="title-input"
              name="title"
              value={formValues.title}
              onChange={handleInputChange}
              required
              fullWidth
              className="input-field"
              error={!!errors.title}
              helperText={errors.title}
              InputProps={{ sx: { height: 40 } }}
            />
          </FormControl>
          <FormControl fullWidth className="form-control">
            <label className="products-title" htmlFor="description-input">Description</label>
            <TextField
              id="description-input"
              name="description"
              value={formValues.description}
              onChange={handleInputChange}
              required
              fullWidth
              className="input-field"
              error={!!errors.description}
              helperText={errors.description}
              InputProps={{ sx: { height: 40 } }}
            />
          </FormControl>
          <FormControl fullWidth className="form-control">
            <label className="products-title" htmlFor="color-input">Color</label>
            <TextField
              id="color-input"
              name="color"
              value={formValues.color}
              onChange={handleInputChange}
              required
              fullWidth
              className="input-field"
              error={!!errors.color}
              helperText={errors.color}
              InputProps={{ sx: { height: 40 } }}
            />
          </FormControl>
          <FormControl fullWidth className="form-control">
            <label className="products-title" htmlFor="price-input">Price</label>
            <TextField
              id="price-input"
              name="price"
              value={formValues.price}
              onChange={handleInputChange}
              type="number"
              required
              fullWidth
              className="input-field"
              error={!!errors.price}
              helperText={errors.price}
              InputProps={{ sx: { height: 40 } }}
            />
          </FormControl>
          <FormControl component="fieldset" required className="input-field" error={!!errors.available}>
            <label className="products-title" >Availability</label>
            <RadioGroup name="available" value={formValues.available} onChange={handleInputChange} row>
              <FormControlLabel value="yes" control={<Radio />} label="Yes" sx={{ fontSize: "14px", color: "#333" }} />
              <FormControlLabel value="no" control={<Radio />} label="No" sx={{ fontSize: "14px", color: "#333" }} />
            </RadioGroup>
            {errors.available && <div className="error">{errors.available}</div>}
          </FormControl>
          <FormControl fullWidth className="form-control">
            <label className="products-title" htmlFor="company-input">Company</label>
            <TextField
              id="company-input"
              name="company"
              value={formValues.company}
              onChange={handleInputChange}
              required
              fullWidth
              className="input-field"
              error={!!errors.company}
              helperText={errors.company}
              InputProps={{ sx: { height: 40 } }}
            />
          </FormControl>
          <button type="submit"  className="submit-button">
            Submit
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default UserProfileModal;
