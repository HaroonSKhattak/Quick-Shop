import React, { useEffect, useState } from 'react';
import { TextField, Button, Dialog, DialogContent, DialogTitle, FormControl, FormControlLabel, FormLabel, Grid, Radio, RadioGroup, } from '@mui/material';
import axios from 'axios';

const UserProfilCategoryModal = (props) => {
  const { isAddModalOpen, setIsAddModalOpen } = props;

  const [formValues, setFormValues] = useState({
    title: '',
  });

  const [errors, setErrors] = useState({
    title: '',
  });

  const handleInputChange = (event) => {
    const { name, value, type, checked } = event.target;
    const newValue = type === 'checkbox' ? checked : value;

    setFormValues((prevValues) => ({
      ...prevValues,
      [name]: newValue,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formErrors = validateForm();
    if (Object.keys(formErrors).length === 0) {
     try {
        await axios.post(`${process.env.REACT_APP_API_URL}/company/create`, formValues)
     } catch(error) {
        console.log(error)
     }
     setIsAddModalOpen(false)
      // Reset form values
      setFormValues({
        title: '',
      });
      // Reset errors
      setErrors({
        title: '',
      });
    } else {
      // Update the errors state with the validation errors
      setErrors(formErrors);
    }
  };

  const validateForm = () => {
    const errors = {};

    // Title validation
    if (!formValues.title.trim()) {
      errors.title = 'Title is required';
    }

    return errors;
  }

  useEffect(() => {handleSubmit()},[])

  return (
    <Dialog open={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} maxWidth="sm">
      <DialogTitle sx={{ fontSize: "16px", fontWeight: 600, color: "#333" }}>Add Category</DialogTitle>
      <DialogContent sx={{ mt: "15px" }}>
        <form className="form" onSubmit={handleSubmit}>
          <FormControl fullWidth className="form-control">
            <label className="products-title" htmlFor="title-input">Title</label>
            <TextField
              id="title-input"
              name="title"
              value={formValues.title}
              onChange={handleInputChange}
              required
              fullWidth
              className="input-field"
              error={!!errors.title}
              helperText={errors.title}
              InputProps={{ sx: { height: 40 } }}
            />
          </FormControl>
          <button type="submit"  className="submit-button">
            Submit
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default UserProfilCategoryModal;
