import React, { useEffect, useState } from 'react';
import '../style.css';
import axios from 'axios';

const AdminUser = () => {
  const [getAllProduct, setGetAllProduct] = useState([]);

  const deleteData = async (id) => {
    try {
      const response = await axios.delete(`${process.env.REACT_APP_API_URL}/user/delete/${id}`);
      console.log(response.data); // handle the response data
    } catch (error) {
      console.error(error); // handle error
    }
  }

  useEffect(() => {
    axios.get(`${process.env.REACT_APP_API_URL}/user/getall`)
      .then((response) => {
        setGetAllProduct(response?.data?.data)
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  }, [])

  return (
    <>
      <div className='user-table-wrapper'>
       
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Id</th>
                <th>UserName</th>
                <th>Email</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {getAllProduct.map((row, index) => (
                <tr key={index}>
                  <td>{row?._id}</td>
                  <td>{row?.username}</td>
                  <td>{row?.email}</td>
                  <td onClick={() => deleteData(row?._id)}>Delete</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  )
}

export default AdminUser