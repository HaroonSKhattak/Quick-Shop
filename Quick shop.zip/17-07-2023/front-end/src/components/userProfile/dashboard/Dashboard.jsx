import React from 'react';
import '../style.css'

const Dashboard = () => {
    return (
        <div className='dashboard-wrapper'>
            <div className='dashboard-content'>
                <div className='dashboard-count'>
                    <h2>10</h2>
                    <p>Orders</p>
                </div>
                <div className='dashboard-count'>
                    <h2>10</h2>
                    <p>Total User</p>
                </div>
                <div className='dashboard-count'>
                    <h2>10</h2>
                    <p>Total Product</p>
                </div>
            </div>
        </div>
    )
}

export default Dashboard