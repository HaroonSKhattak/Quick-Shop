import {
  Grid,
  Box,
  Typography,
  TextField,
  Button,
  Card,
  CardContent,
  CardActions,
  CardMedia,
} from "@mui/material";
import { useEffect, useState } from "react";
import axios from "axios";
const Scrap = () => {
  const [products, setProducts] = useState([]);
  const [query, setQuery] = useState("");

  const handleSearch = async () => {
    try {
      setProducts([]);
      const { data } = await axios.post(
        `${process.env.REACT_APP_API_URL}/scrap`,
        { query }
      );
      setProducts(data?.data);
    } catch (error) {}
  };
  const handleChange = (event) => {
    const { value } = event.target;
    setQuery(value);
  };

  return (
    <Box
      sx={{
        padding: "0 4.8rem",
      }}
    >
      <Typography variant="h2" textAlign={"center"}>
        Scrap
      </Typography>
      <Box sx={{ display: "flex", justifyContent: "center", my: 2 }}>
        <Grid container sx={{ width: 300 }}>
          <Grid item xs>
            <TextField
              placeholder="Search..."
              fullWidth
              onChange={handleChange}
              
            />
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              sx={{ height: "100%" }}
              onClick={handleSearch}
            >
              Search
            </Button>
          </Grid>
        </Grid>
      </Box>

      <Box sx={{ display: "flex", justifyContent: "center", width: "100%" }}>
        <Grid container spacing={2}>
          {products.map((product) => {
            return (
              <Grid item md={4}>
                <Card sx={{ maxWidth: 345 }}>
                  <CardMedia
                    sx={{ height: 140, backgroundSize: "contain" }}
                    image={product.url}
                    title={product.title}
                  />
                  <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                      {product.title}
                    </Typography>

                    <Typography variant="body1" color="text.secondary">
                      {product.price}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </Box>
    </Box>
  );
};

export default Scrap;
