import { configureStore } from '@reduxjs/toolkit';
import { setupListeners } from '@reduxjs/toolkit/query';
import { productSlice } from './slice/productSlice';
import { userSlice } from './slice/userSlice';

const store = configureStore({
  reducer: {
    [productSlice.reducerPath]: productSlice.reducer,
    [userSlice.reducerPath]: userSlice.reducer,
    // other reducers...
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(productSlice.middleware, userSlice.middleware),
});

setupListeners(store.dispatch);

export default store;
