import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const userSlice = createApi({
  reducerPath: 'productSlice',
  baseQuery: fetchBaseQuery({ baseUrl: 'http://localhost:5000' }), // Replace with your backend URL
  endpoints: (builder) => ({
    // Define your API endpoints here
    register: builder.mutation({
      query: (formData) => ({
        url: '/user/register',
        method: "POST",
        body: formData
      }),
    }),
    login: builder.mutation({
      query: (formData) => ({
        url: '/user/login',
        method: "POST",
        body: formData
      }),
    }),
    // more endpoints...
  }),
});

export const { useRegisterMutation, useLoginMutation } = userSlice;
