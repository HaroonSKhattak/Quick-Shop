import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const productSlice = createApi({
  reducerPath: 'productSlice',
  baseQuery: fetchBaseQuery({ baseUrl: 'http://localhost:5000' }), // Replace with your backend URL
  endpoints: (builder) => ({
    getProduct: builder.query({
      query: () => ({
        url: "/product/getAll",
        method: "GET",
      }),
    }),
    // more endpoints...
  }),
});

export const { useGetProductQuery } = productSlice;
